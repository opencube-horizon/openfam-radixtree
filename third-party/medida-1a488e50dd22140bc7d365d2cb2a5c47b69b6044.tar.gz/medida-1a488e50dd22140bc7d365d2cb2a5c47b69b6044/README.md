Medida - Simple metrics for C++ programs
========================================

*NOTE: Work in progress and not for human consumption! Go away!*

Project homepage and documentation: http://dln.github.com/medida/

Created out of envy of Coda Hale's awesome Metrics library for the JVM.


Copyright
---------
Copyright (c) 2012 Daniel Lundin

This software is licensed under the Apache License, Version 2.0.
Please see LICENSE for details.
